-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2023 at 02:13 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flower_power`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE `artikel` (
  `artikelcode` int(255) NOT NULL,
  `artikel` varchar(255) NOT NULL,
  `prijs` decimal(10,0) NOT NULL,
  `omschrijving` text NOT NULL,
  `foto` varchar(255) NOT NULL,
  `bestand` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`artikelcode`, `artikel`, `prijs`, `omschrijving`, `foto`, `bestand`) VALUES
(1, 'bloemen1', '50', 'Een mooi bouquet', 'foto.jpg', 'foto.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `bestelling`
--

CREATE TABLE `bestelling` (
  `artikelcode` int(255) NOT NULL,
  `winkelcode` int(255) NOT NULL,
  `aantal` int(255) NOT NULL,
  `klantcode` int(255) NOT NULL,
  `medewerkerscode` int(255) NOT NULL,
  `afgehaald` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `factuur`
--

CREATE TABLE `factuur` (
  `factuurnummer` int(11) NOT NULL,
  `factuurdatum` date NOT NULL,
  `klantcode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `factuur`
--

INSERT INTO `factuur` (`factuurnummer`, `factuurdatum`, `klantcode`) VALUES
(1, '2022-12-31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `factuurregel`
--

CREATE TABLE `factuurregel` (
  `factuurnummer` int(255) NOT NULL,
  `artikelcode` int(255) NOT NULL,
  `aantal` int(11) NOT NULL,
  `prijs` decimal(11,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `klanten`
--

CREATE TABLE `klanten` (
  `klantcode` int(11) NOT NULL,
  `voornaam` varchar(255) NOT NULL,
  `tussenvoegsels` varchar(20) NOT NULL,
  `achternaam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `adres` varchar(255) NOT NULL,
  `postcode` varchar(255) NOT NULL,
  `woonplaats` varchar(255) NOT NULL,
  `geboortedatum` date NOT NULL,
  `gebruikersnaam` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `klanten`
--

INSERT INTO `klanten` (`klantcode`, `voornaam`, `tussenvoegsels`, `achternaam`, `email`, `adres`, `postcode`, `woonplaats`, `geboortedatum`, `gebruikersnaam`, `password`) VALUES
(0, 'Jan', '', 'Pieter', 'JanPieter@gmail.com', 'Sesamstraat 123', '1234AB', 'Amsterdam', '2000-01-01', 'Janpieter', '123'),
(0, 'test', '', 'test', 'randomiets@hotmail.com', 'Sesamstraat 123', '1234AB', 'Amsterdam', '2023-01-14', 'hoi', '$2y$04$khY00EydW/hi0WFFJ3gHqOXXbCthWKLQs4P4TqudA222uFDUKABwi'),
(0, 'test2', '', 'test2', 'email@hotmail.com', 'Sesamstraat 123', '1234XY', 'Amsterdam', '2023-01-03', 'Gebruiker', '$2y$04$8yn.dEoWKr6QIbX2ojfkjen5/FzWQueI5LBSOZ4PfOHuSmKIVMwxy'),
(0, 'hoi1', '', 'hoi2', 'test@hotmail.com', 'Sesamstraat 123', '1234AB', 'Amsterdam', '2023-01-19', 'hoihoihoi', '$2y$04$1KYZBT2KpmeE8c1cE5Wl3uOwZRSPDyoXLiigh/o0iXEcjNsLxntxK');

-- --------------------------------------------------------

--
-- Table structure for table `medewerker`
--

CREATE TABLE `medewerker` (
  `Medewerkerscode` int(255) NOT NULL,
  `voornaam` varchar(255) NOT NULL,
  `tussenvoegsels` varchar(10) NOT NULL,
  `achternaam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medewerker`
--

INSERT INTO `medewerker` (`Medewerkerscode`, `voornaam`, `tussenvoegsels`, `achternaam`, `email`, `password`) VALUES
(2, 'hoi1', '', 'hoi2', 'email@hotmail.com', '$2y$04$3r3CuaplBGpzW1wwKscEEu13P7807TZzMw/U1iaPWjalvh5KSpB0q'),
(3, 'Patrick', '', 'Agramonte', 'testemail@hotmail.com', '$2y$04$FOaNmn6kso2ip43uHCtkNOqu4WE9U3NiWu7CDa07B7Ef5dXjwZoGC'),
(4, 'iemand', '', 'achternaam', 'stefan@email.com', '$2y$04$4g7DPj9z2PnG05nggi1FpOasrG5jWNH/4Mb9UxX8WRBpjhlPUZMxu');

-- --------------------------------------------------------

--
-- Table structure for table `winkel`
--

CREATE TABLE `winkel` (
  `winkelcode` int(255) NOT NULL,
  `winkelnaam` varchar(255) NOT NULL,
  `winkeladres` varchar(255) NOT NULL,
  `winkelpostcode` varchar(7) NOT NULL,
  `vestigingsplaats` varchar(255) NOT NULL,
  `telefoonnummer` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`artikelcode`);

--
-- Indexes for table `bestelling`
--
ALTER TABLE `bestelling`
  ADD UNIQUE KEY `BestellingIndex` (`artikelcode`,`winkelcode`,`medewerkerscode`,`klantcode`) USING BTREE,
  ADD KEY `FK_Medewerker` (`medewerkerscode`),
  ADD KEY `FK_Winkel` (`winkelcode`),
  ADD KEY `FK_Klanten` (`klantcode`);

--
-- Indexes for table `factuur`
--
ALTER TABLE `factuur`
  ADD PRIMARY KEY (`factuurnummer`),
  ADD UNIQUE KEY `klant3` (`klantcode`);

--
-- Indexes for table `factuurregel`
--
ALTER TABLE `factuurregel`
  ADD UNIQUE KEY `FactuurIndex` (`factuurnummer`,`artikelcode`),
  ADD KEY `FK_Artikel` (`artikelcode`);

--
-- Indexes for table `medewerker`
--
ALTER TABLE `medewerker`
  ADD UNIQUE KEY `medewerkerscode1` (`Medewerkerscode`);

--
-- Indexes for table `winkel`
--
ALTER TABLE `winkel`
  ADD PRIMARY KEY (`winkelcode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
  MODIFY `artikelcode` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `factuur`
--
ALTER TABLE `factuur`
  MODIFY `factuurnummer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `medewerker`
--
ALTER TABLE `medewerker`
  MODIFY `Medewerkerscode` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `winkel`
--
ALTER TABLE `winkel`
  MODIFY `winkelcode` int(255) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bestelling`
--
ALTER TABLE `bestelling`
  ADD CONSTRAINT `FK_Factuurregel` FOREIGN KEY (`artikelcode`) REFERENCES `factuurregel` (`artikelcode`),
  ADD CONSTRAINT `FK_Klanten` FOREIGN KEY (`klantcode`) REFERENCES `klanten` (`klantcode`),
  ADD CONSTRAINT `FK_Medewerker` FOREIGN KEY (`medewerkerscode`) REFERENCES `medewerker` (`Medewerkerscode`),
  ADD CONSTRAINT `FK_Winkel` FOREIGN KEY (`winkelcode`) REFERENCES `winkel` (`winkelcode`);

--
-- Constraints for table `factuurregel`
--
ALTER TABLE `factuurregel`
  ADD CONSTRAINT `FK_Artikel` FOREIGN KEY (`artikelcode`) REFERENCES `artikel` (`artikelcode`),
  ADD CONSTRAINT `FK_Factuur` FOREIGN KEY (`factuurnummer`) REFERENCES `factuur` (`Factuurnummer`);

--
-- Constraints for table `klanten`
--
ALTER TABLE `klanten`
  ADD CONSTRAINT `FK_Klantcode` FOREIGN KEY (`klantcode`) REFERENCES `factuur` (`Klantcode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
